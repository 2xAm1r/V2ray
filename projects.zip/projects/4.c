#include <stdio.h>


int main()
{

    int adad = 10;
    int age;

        printf("Enter your age: ");
        scanf("%d",&age);
    
    

        printf("%d",age);    






}