#include <stdio.h>

int main()
{

    char mode;
    printf("Mode ro vared kon: ");
    scanf("%c", &mode);

    switch (mode)
    {

    case 'a':
        printf("\nA1");
        break;

    case 'b':
        printf("\nB1");
        break;

    case 'c':
        printf("\nC1");
        break;

    default:
        printf("\n Wrong!");
        break;
    }

    return 0;
}