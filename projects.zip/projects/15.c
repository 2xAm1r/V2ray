#include <stdio.h>


int main(){
    int i = 0;
    while( 1 )
    {
        printf("\n%d ", i);
        i++;

        if ( i ==213) {
            continue;
        }

        if (i == 213)
        {
            break;
        }
        
        
    }

    return(0);

}