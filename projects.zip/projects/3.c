#include <stdio.h>

#define bechap printf

#define version 23542

int main(){

    bechap ("Hello world!");

    printf("Version: %d" , version); 

}