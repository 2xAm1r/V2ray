#include <stdio.h>
#include <string.h>


int main(){

    char *text = "Hello world!",
         text2[] = "Hello World!";

 
    printf("%c", text2[ strlen(text2)-1 ] );

    return(0);
}