#include <stdio.h>


int zarb(int,int);
char ascii2char(int ascii);
void sayhello();

int main( int argc , char **argv ){

    printf("%d\n" ,   zarb(3,4)    );

    printf("%c", ascii2char(65) ); 
    
    sayhello();

    printf("\n\n\n%s", argv[0]);


    return 0;
}


void sayhello(){
    printf("\nHello\n");
}



int zarb(int adad1,int adad2)
{
    int result;
    result = adad1 * adad2;

    return result;
}


char ascii2char(int ascii)
{
    char c = ascii;

    return c;
}