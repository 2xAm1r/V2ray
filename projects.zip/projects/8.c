#include <stdio.h>


int main(){


        int i[10];
        char c[20] = {'H','e','l','l','o'};
        c[4] = '\0';

        printf("%c",c[4]);
    
}