#include <stdio.h>


int main(){


    float f = 2.16;
    double p;

    printf("Adad pi chande? ");
    scanf("%lf" , &p);

    printf("%.3g",p);


}