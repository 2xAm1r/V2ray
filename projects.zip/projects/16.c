#include <stdio.h>


int main(){
  
    int i = 0, b =1 ;

    LL1:
    i = 1;

    printf("%d",i);
    i = b;
    printf("%d",i);
    
    printf("Barname tamam shod, mikhay dobare ejra beshe? ");
    scanf("%d",&i);

    if (i == 1){
        goto LL1;

    }else if (i == 2){
        goto LL2;
    }

    return(0);




    LL2:
    printf("Label 2e inja");
    return(0);
}