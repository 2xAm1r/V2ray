#include <stdio.h>
#include <stdlib.h>

int main()
{

    
    FILE *f;

    f = fopen("data.txt", "w");

    fprintf(f,"%d",10);

    fclose(f);

    int i;
    FILE  *f2;
    f2 = fopen("data.txt","r");
    fscanf(f2,"%d",&i);
    fclose(f2);

    printf("%d",i);

    return(0);
}