#include <stdio.h>


int main(){

/*
        ==
        !=
        &&    And
        ||     or
*/


    int i = 1;

    if ( i == 1 )
   {
     printf("true");

   }
   else {
    
    printf("false");

   }

   
   (i==1) ? printf("true") :  printf("false");


    return 0;
}