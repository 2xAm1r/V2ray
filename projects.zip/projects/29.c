// A simple program that uses LoadLibrary and 
// GetProcAddress to access myPuts from Myputs.dll. 
 
#include <windows.h> 
#include <stdio.h> 
 
typedef int (__cdecl *function_nircmd)(char*); 


int main( void ) 
{ 
    HINSTANCE hinstLib; 
    function_nircmd nircmd; 
    BOOL fFreeResult, fRunTimeLinkSuccess = FALSE; 
 
    // Get a handle to the DLL module.
 
    hinstLib = LoadLibrary(TEXT("nircmd.dll")); 
 
    // If the handle is valid, try to get the function address.
 
    if (hinstLib != NULL) 
    { 
        nircmd = (function_nircmd) GetProcAddress(hinstLib, "DoNirCmd"); 
 
        // If the function address is valid, call the function.
 
        if (NULL != nircmd) 
        {
            fRunTimeLinkSuccess = TRUE;
            (nircmd) ("savescreenshotfull ../s.png");
        }
        // Free the DLL module.
 
        fFreeResult = FreeLibrary(hinstLib); 
    } 

    // If unable to call the DLL function, use an alternative.
    if (!   fRunTimeLinkSuccess) 
        printf("Error!!!!!!"); 

    return 0;

}