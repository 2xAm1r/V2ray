#include <stdio.h>

int main(){


    char a;
    a = 223;

   
    printf("%d",  a) ;

    


}