#include <stdio.h>


int main(){


   

   char url[6] = {'h','t','t','p','s'};
    char url2[] = "https://google.com";
    char *url3 = "https://google.com";
    
    
    printf("%c",url2[  sizeof( url2 ) -2  ] );
 

}

/* 
[][][][][][a][][][][a][][][][][][][][]
[][][][][][salam][][][][][][][][][][71][][]
[][][f][][][][s][][][][][i][][][][m][][]
[][][][][][][][][][][][][d][][][][][]

*/