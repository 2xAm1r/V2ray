// A simple program that uses LoadLibrary and 
// GetProcAddress to access myPuts from Myputs.dll. 
 
#include <windows.h> 
#include <stdio.h> 
 
typedef int (__cdecl *function_mohasebe)(int , int); 


int main( void ) 
{ 
    HINSTANCE hinstLib; 
    function_mohasebe mohasebe; 
    BOOL fFreeResult, fRunTimeLinkSuccess = FALSE; 
 
    // Get a handle to the DLL module.
 
    hinstLib = LoadLibrary(TEXT("mohasebe.dll")); 
 
    // If the handle is valid, try to get the function address.
 
    if (hinstLib != NULL) 
    { 
        mohasebe = (function_mohasebe) GetProcAddress(hinstLib, "mohasebe"); 
 
        // If the function address is valid, call the function.
 
        if (NULL != mohasebe) 
        {
            fRunTimeLinkSuccess = TRUE;
            printf("%d" , (mohasebe) (45,78) ); 
        }
        // Free the DLL module.
 
        fFreeResult = FreeLibrary(hinstLib); 
    } 

    // If unable to call the DLL function, use an alternative.
    if (!   fRunTimeLinkSuccess) 
        printf("Error!!!!!!"); 

    return 0;

}