#include <stdio.h>
#include <string.h>
#include <stdlib.h>


void ramznegari();

void tarjome();


int main()
{
    int mode;

    // Taghire range matn
    system("cls");
    system("color 02");

    START:
    // Entekhabe mode
    printf("Mode morede nazaro entekhab kon [Ramznegari: 1] [Tarjome 2] [Exit 0]: ");
    scanf("%d",&mode);

    switch (mode)
    {
    case 1:
        // Ramznegari
        ramznegari();
        break;
    case 2:
        // Tarjome
        tarjome();
        break;
    case 0:
        // Exit
        exit(0);
    
    default:
        break;
    }

    goto START;
    return (0);
}



void ramznegari(){

    char text[500];
    int ascii;

    printf("\n\n\tTexte morede nazaro vared kon: ");
    scanf("%s",text);

    for ( int i=0 ; i<strlen(text) ; i++ )
    {
        ascii = (int)text[i];
        ascii = ascii + 2;
        text[i] = (char)ascii;
    }

    printf("\n\n\t%s\n\n", text );
}



void tarjome(){

    char text[500];
    int ascii;

    printf("\n\n\tMatne ramz shodeye khod ra vared kon: ");
    scanf("%s",text);

    for ( int i=0 ; i<strlen(text) ; i++ )
    {
        ascii = (int)text[i];
        ascii = ascii - 2;
        text[i] = (char)ascii;
    }

    printf("\n\n\t%s\n\n", text );
}