

int mohasebe(int x, int y){

  return  (  ( x * y ) / 2 ) + 100;

}