#include <stdio.h>


struct server {
    int id;
    char *host;
    int port;
};


int main(){
 
    struct server iran;
    struct server us;
    struct server uk;

    iran.id = 1;
    iran.host = "127.0.0.1";
    iran.port = 8080;

    us.id= 2;
    us.host = "";
    us.port = 8080;


    printf("%d" , us.port);

    
    

    return(0);

}