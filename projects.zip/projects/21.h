#include <stdio.h>



void hello (){

    printf("hellow world!");
 

}