
#include "21.h"

int main()
{
    hello();

    return(0);
}