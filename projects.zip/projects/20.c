#include <stdio.h>
#include <string.h>

/*
strcpy
strcat
strstr

*/

int main(){

    char *text;
    char *text2 = "How r u?" ;
    strcpy( text ,  "world! ");
    
    strcat( text ,   text2);

    if (strstr(text,"end") ){

    printf("exist");

    }



    return(0);
}