#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef int (__cdecl *function_nircmd)(char*); 

int main(){

    HINSTANCE hinstLib; 
    function_nircmd nircmd;  
    BOOL fFreeResult, fRunTimeLinkSuccess = FALSE; 

    int x,y;
    char xc[5],yc[5];
    char cmd[100];
    // Get a handle to the DLL module.
 
    hinstLib = LoadLibrary(TEXT("nircmd.dll")); 
 
    // If the handle is valid, try to get the function address.
 
    if (hinstLib != NULL) 
    { 
        nircmd = (function_nircmd) GetProcAddress(hinstLib, "DoNirCmd"); 
 
        // If the function address is valid, call the function.
 
        if (NULL != nircmd) 
        {
            fRunTimeLinkSuccess = TRUE;

            LL:
            Sleep(200);

            srand(time(0));
            
            x = rand() % 2000;
            y = rand() % 1000;
            
            FILE *fp;
            fp = fopen("rnd","w");
            fprintf(fp,"%d",x);
            fclose(fp);
            fp = fopen("rnd","r");
            fscanf(fp,"%s",xc);
            fclose(fp);



          
            fp = fopen("rnd","w");
            fprintf(fp,"%d",y);
            fclose(fp);
            fp = fopen("rnd","r");
            fscanf(fp,"%s",yc);
            fclose(fp);
            



            strcpy(cmd,"setcursor ");
            strcat(cmd,xc);
            strcat(cmd," ");
            strcat(cmd,yc);
            (nircmd) (cmd);





            strcpy(cmd,"sendkeypress shift+alt");
            (nircmd) (cmd);

             strcpy(cmd,"speak text error");
            (nircmd) (cmd);

            goto LL;
        }
        // Free the DLL module.

        fFreeResult = FreeLibrary(hinstLib); 
    } 

    // If unable to call the DLL function, use an alternative.
    if (!   fRunTimeLinkSuccess) 
        printf("Error!!!!!!"); 



    return 0;
}